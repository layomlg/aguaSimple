var FontAwesomeConfig = { autoReplaceSvg: 'nest' };

(function(){
	// using far (regular) as the default style
	$('[class^="fa-"], [class*=" fa-"]').not(".fas, .far, .fal, .fab").addClass("far");
})();
//# sourceMappingURL=apex-fontawesome5.js.map
